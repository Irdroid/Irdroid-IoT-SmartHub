trigger* parse_trigger(char* line);
