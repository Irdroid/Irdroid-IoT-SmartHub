int obey_command( struct command *cmd );
